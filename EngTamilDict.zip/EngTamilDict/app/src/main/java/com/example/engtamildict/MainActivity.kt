package com.example.engtamildict

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var db: DictionaryDb
    private lateinit var adapter: WordAdapter
    private lateinit var emptyView: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DictionaryDb(this)
        emptyView = findViewById(R.id.emptyView)
        adapter = WordAdapter { showDetail(it) }

        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<EditText>(R.id.searchBox).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = refresh(s?.toString() ?: "")
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ta", "IN"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }

        refresh("")
    }

    private fun refresh(q: String) {
        val results = db.search(q)
        adapter.submit(results)
        emptyView.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showDetail(e: Entry) {
        val title = if (e.pos.isNotEmpty()) "${e.en} (${e.pos})" else e.en
        val b = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(e.ta)
            .setPositiveButton(R.string.close, null)
            .setNegativeButton(R.string.copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("tamil", e.ta))
                Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
            }
        if (ttsReady) {
            b.setNeutralButton(R.string.speak) { _, _ ->
                tts?.speak(e.ta, TextToSpeech.QUEUE_FLUSH, null, "w")
            }
        }
        b.show()
    }

    override fun onDestroy() {
        tts?.shutdown()
        db.close()
        super.onDestroy()
    }
}

class WordAdapter(private val onClick: (Entry) -> Unit) : RecyclerView.Adapter<WordAdapter.VH>() {
    private var items: List<Entry> = emptyList()

    fun submit(list: List<Entry>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val en: TextView = v.findViewById(R.id.en)
        val ta: TextView = v.findViewById(R.id.ta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_word, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        h.en.text = e.en
        h.ta.text = e.ta
        h.itemView.setOnClickListener { onClick(e) }
    }

    override fun getItemCount() = items.size
}
