package com.example.engtamildict

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Entry(val en: String, val pos: String, val ta: String)

/** Loads assets/dictionary.csv (format: english|part-of-speech|tamil) into SQLite on first run. */
class DictionaryDb(private val ctx: Context) : SQLiteOpenHelper(ctx, "dict.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, en TEXT NOT NULL COLLATE NOCASE, pos TEXT, ta TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_en ON entries(en)")
        db.beginTransaction()
        try {
            ctx.assets.open("dictionary.csv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { line ->
                    val p = line.split("|")
                    if (p.size >= 3 && p[0].isNotBlank()) {
                        db.execSQL(
                            "INSERT INTO entries(en,pos,ta) VALUES(?,?,?)",
                            arrayOf(p[0].trim(), p[1].trim(), p[2].trim())
                        )
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS entries")
        onCreate(db)
    }

    fun search(query: String): List<Entry> {
        val q = query.trim()
        val cursor = if (q.isEmpty()) {
            readableDatabase.rawQuery("SELECT en,pos,ta FROM entries ORDER BY en LIMIT 300", null)
        } else {
            readableDatabase.rawQuery(
                "SELECT en,pos,ta FROM entries WHERE en LIKE ? OR ta LIKE ? " +
                    "ORDER BY (en LIKE ?) DESC, en LIMIT 300",
                arrayOf("$q%", "%$q%", "$q%")
            )
        }
        val out = ArrayList<Entry>()
        cursor.use { while (it.moveToNext()) out.add(Entry(it.getString(0), it.getString(1) ?: "", it.getString(2))) }
        return out
    }
}
