# English–Tamil Dictionary (Android)

Standalone, offline app. Kotlin, SQLite, no network permission.

## Build the APK
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk
   Or from a terminal with the Gradle wrapper generated: ./gradlew assembleDebug

## Add words
Edit app/src/main/assets/dictionary.csv, one entry per line: english|part-of-speech|tamil
Then bump the database version in DictionaryDb.kt (1 -> 2) so it reloads.
